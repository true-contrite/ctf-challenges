   
#include <stdio.h>  	    		
		    	
   	 	 	  
		int main(void)   	 {
   	   		 printf("\n--=============================--\n\n");
		printf("I do hate Python\n"); 		
   				 		
		printf("How dare it make me	 indent\n"); 
   		 	  	
		printf("I'll do what I want\n\n");	 	
   	 					
		    		 
   		 		 	
		printf("If I want a tab\n");			
   		 	  	
		printf("I will put it where	 I want\n"); 
   			  		
		printf("Not where it tells me\n\n");	  	
   			  		
		    	 	 
   	 					
		    	 		
   	 	    
		    		  
   				  	
		    		 	
   	 	 	  
		    			 
   		 	   
		    				
   		    
		    	    
   		 			 
		    	   	
   	 					
		    	  	 
   			 	 
		    	  		
   	 	   
		    	 	  
   			 	 
		    	 	 	
   	 	   
		    	 		 
   					 	
		    	 			
printf("Python go away\n");  
		printf("Give me back my freedom now\n");

 	 			 			 			  	  		 	  	 			 	   		  	 	

 	 		 			  		  	 	 			 			 		 		   		 	  	 		 			  		  	 	




   		printf("I will just use C\n");	 		  	   		  	  
	   
	

   			 			 			  	  		 	  	 			 	   		  	 	
 
 			 
 
	  			 			 			  	  		 	  	 			 	   		  	 	 	 					 		  	 	 		 			  		  	  
	
     	
	   
 
 			 			 			  	  		 	  	 			 	   		  	 	

   			 			 			  	  		 	  	 			 	   		  	 	 	 					 		  	 	 		 			  		  	  
 

 


	

   			  	  		  	 	 		    	 		  	  
 
  
 	
	 			 
    	 	 printf("\n--=============================--\n");
	  	
	  			  	  		  	 	 		    	 		  	   	 					 		  	 	 		 			  		  	  
 

   	
	   
 
 			  	  		  	 }	 		    	 		  	  

   			  	  		  	 	 		    	 		  	   	 					 		  	 	 		 			  		  	  
 

   	
	       
		 
	

   		 			  		  	 	 			 			 		 		   		 	  	 		 			  		  	 	
   	 	 
   		 	
	
  	
  
	
